# Ixera one-page site

Fichiers à déposer dans GitHub, dépôt Ixera/web.

1. Remplacer `index.html` par celui-ci.
2. Ajouter `styles.css`.
3. Ajouter `script.js`.
4. Créer un dossier `assets`.
5. Ajouter `jean-francois-lavigne.jpg` dans `assets`.
6. Commit changes.

Vercel publiera automatiquement.
