const toggle = document.querySelector('.lang-toggle');
let lang = 'fr';
function setLang(next) {
  lang = next;
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-fr]').forEach((el) => {
    el.textContent = el.dataset[lang];
  });
  toggle.textContent = lang === 'fr' ? 'EN' : 'FR';
  document.title = lang === 'fr' ? 'Ixera | Continuité managériale' : 'Ixera | Management continuity';
}
toggle.addEventListener('click', () => setLang(lang === 'fr' ? 'en' : 'fr'));
document.getElementById('year').textContent = new Date().getFullYear();
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) entry.target.classList.add('in');
  });
}, { threshold: 0.12 });
document.querySelectorAll('.reveal').forEach((el) => observer.observe(el));
